a=("Harshit")

print(a.__len__())

print(len(a))
