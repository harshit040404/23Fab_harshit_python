
from re import A


a = int(input("Enter a number: "))
if (a % 2) == 0:
   print("is Even")
else:
   print("is Odd")