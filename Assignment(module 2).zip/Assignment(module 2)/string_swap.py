

a1='rajkot'
a2='ahemdabad'
 
x=a2[0:2]+a1[2:]
y=a1[0:2]+a2[2:]

print(f"now a1 is :{x}")
print(f"now a1 is :{y}")