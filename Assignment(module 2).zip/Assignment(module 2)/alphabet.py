a=str(input("Enter Alphabets :"))

if a=="A" and a=="E" and a=="I" and a=="O" and a=="U" and a=="a" and a=="e" and  a=="i" and a=="o" and a=="u":
   print("Alphabet is Vowel")
else:
   print("Alphabets is consonent")   