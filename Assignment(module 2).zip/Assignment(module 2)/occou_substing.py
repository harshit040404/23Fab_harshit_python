
a="python is my favorite lanuage"
print(a.count("t"))