base=input("enter base of triangle :")
height=input("enter height of triangle :")

areaoftriangle=0.5*base*height
print(f"area of triangle is :{areaoftriangle}")

#circle

radius=input("enter radius of circle :")
areaofcircle=3.14*radius*radius
print(f"area of circle is :{areaofcircle} ")