
a=str(input("Enter a sting:"))

if len(a)%4==0:
    print(a[::-1])
else :
    print("sting length is not multiple of 4 .")
