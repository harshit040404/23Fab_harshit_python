
a=input("Enter String :")

if a.isalpha():
    print(len(a))
else:
    print("Enter alphabatic words")