list=[]

for i in range(1,6):
    list += [i**2]

for i in range(6,26):
    list += [i]

for i in range(26,31):
    list += [i**2]

print(list)