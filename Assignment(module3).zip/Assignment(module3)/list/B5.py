ML=[5,10,15,-20,30,-2,4,-55]

print("Maximum Number In List Is : ",max(ML))
print("Minimum Number In List Is : ",min(ML))

sum=ML[0]+ML[1]+ML[2]+ML[3]+ML[4]+ML[5]+ML[6]+ML[7]
print("Total Sum Is : ",sum)