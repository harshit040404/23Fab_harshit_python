str=""
list1=["p","y","t","h","o","n"]
str1=str.join(list1)
print(str1)