list1=[2,33,222,14,25]
print(list1[-1])