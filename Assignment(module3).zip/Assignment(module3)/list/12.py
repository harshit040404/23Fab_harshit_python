list=[1,2,3,4,3,3,6,9,6]
list=list(dict.fromkeys(list))
print(list)