import random
random.seed(4)
print(random.randint(100,999))