b1=int(input("Enter Length of Base 1 : "))
b2=int(input("Enter Length of Base 2 : "))
h=int(input("Enter Height : "))

area=1/2*(b1+b2)*h

print("Area of Trapazoid Is  : ",area)