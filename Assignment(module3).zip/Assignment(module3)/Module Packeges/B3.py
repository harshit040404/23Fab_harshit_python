import random
a=random.randint(1000,9999)
print(a)