decimal_num=(8.2,59.3,24.8,19.78,17.57,17.10,50.78)
print(max("Max Decimal Is : ",decimal_num))
print(min("Min Decimal Is : ",decimal_num))