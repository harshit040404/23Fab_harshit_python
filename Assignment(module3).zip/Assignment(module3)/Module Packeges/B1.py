import random
mylist=[11,22,33,44,55,66]

print(random.choice(mylist))