import random
a = random.randrange(10,101)
print(a)