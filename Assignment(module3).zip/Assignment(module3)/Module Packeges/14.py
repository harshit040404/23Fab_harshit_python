b=int(input("Enter Length of Base : "))
h=int(input("Enter Height : "))

area = b*h

print("Parallelogram Is : ",area)