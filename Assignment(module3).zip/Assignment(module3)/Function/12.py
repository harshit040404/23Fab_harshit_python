def f1():
    a = "This is python language"

print(f1.__code__.co_nlocals)