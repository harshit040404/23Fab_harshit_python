def f1():
    a = "This is python language"
      
    def f2():
        print(a)
    f2()
f1()