def num_range():

    b=int(input("Enter a number : "))

    if b in range(100,1001):
        print("Entered Number is in range")
    else :
        print("Enter a number in range")

num_range()