myf={"csk":"dhoni", "dc":"de cock","dd":"dhaval"}
if "dav" in myf.keys():
    print("Yes")