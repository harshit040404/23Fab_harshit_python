from re import X


mydict={1: 'brinda', 2: 'chandni', 3: 'alex'}
x=mydict.values()
print(x)