mydict={1: 'brinda', 2: 'chandni', 3: 'alex', 4: 'krupa'}

print(sorted(mydict.values()))