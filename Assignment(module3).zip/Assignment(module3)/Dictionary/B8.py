a=input("Enter any key : ")
mydict={"csk":"dhoni", "dc":"de cock","dd":"dhavan"}


if a in mydict:
    print("yes exist...")
else:
    print("not exist")