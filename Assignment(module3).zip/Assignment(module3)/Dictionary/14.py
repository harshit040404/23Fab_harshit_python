l1=[1,2,3,4]
l2=["brinda","chandni","priya","grishma"]

mydict=dict(zip(l1,l2))
print(mydict)
