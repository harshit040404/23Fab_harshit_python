tup=((1,"bombay"),(2,"channai"),(3,"allhabad"),(4,"Kolkata"))

mydict=dict((x,y) for x,y in tup)

print(mydict)