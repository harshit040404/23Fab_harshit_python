mydict={}

for i in range(1,16):
    mydict[i]=i*i
    
print(mydict)