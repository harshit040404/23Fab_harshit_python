mydict={"id":17,"name":"harshit","sub":"computer"}

print(mydict.keys()>={"id","name"})