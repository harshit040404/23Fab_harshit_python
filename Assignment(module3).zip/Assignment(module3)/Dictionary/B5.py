mydict={1: 'brinda', 2: 'chandni', 3: 'alex'}
myf={"csk":"dhoni", "dc":"de cock","dd":"dhaval"}

myf.update(mydict)
print(myf)