mytup=(1,"hello","this is python","tuple example")
x=len(mytup)
print(x)