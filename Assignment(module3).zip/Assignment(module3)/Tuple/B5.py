mytup=()

if len(mytup) == 0:
    print("tuple is empty")
else:
    print("tuple is not empty")