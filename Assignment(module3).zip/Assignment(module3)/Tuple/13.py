mytup=(1,3,4,6,4,7,4,5,9,4,3,5,4,5,3,5,4,5,4,3)
n=int(input("Enter the no. want to count : "))
x=mytup.count(n)
print(x)