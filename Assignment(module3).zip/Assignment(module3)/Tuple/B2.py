mytup=(1,"python",True,11j)
print(mytup)