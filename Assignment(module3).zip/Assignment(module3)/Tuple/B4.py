mytup=('p','y','t','h','o','n')
str=""
str1=str.join(mytup)
print(str1)