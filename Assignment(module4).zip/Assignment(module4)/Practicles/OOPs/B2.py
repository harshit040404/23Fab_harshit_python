#How To Define a Class in Python?What Is Self?Give An Example Of A Python Class

# to define a class 'class' keyword is used
# example of class

class student :
    name=input("Enter ur Name : ")
    city=input("Enter ur City : ")
    print(name)
    print(city)


# by using "self" keyword we can access the attributes and methods of class in python.