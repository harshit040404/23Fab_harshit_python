try :
    a=int(input("Enter a number : "))
    if a%2!=0 :
        print("Number is odd")
    else :
        print("Error ..... Not an odd number.")

except:
    print("Error!!!")