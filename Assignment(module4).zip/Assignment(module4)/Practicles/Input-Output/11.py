x=open("data.txt","r")
list1=[print(x.readlines())]