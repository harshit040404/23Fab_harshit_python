x=open("data.txt","r")
print(len(x.readlines()))