#x=open("data.txt","x")

x=open("data.txt","r+")

#x.write("There are 7 days in a Week.")
#x.write("\n 4 weeks in a month.")
#x.write("\n12 months in a year.")

print(x.read())