x=open("data.txt","r")

w=x.readlines()[0]

print(len(w))