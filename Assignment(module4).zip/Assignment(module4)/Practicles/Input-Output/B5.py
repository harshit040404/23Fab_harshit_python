x=open("data.txt","r")
print(x.readlines()[:-2:-5])