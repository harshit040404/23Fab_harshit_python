x=open("data.txt","r")

print(x.readlines()[0:3])