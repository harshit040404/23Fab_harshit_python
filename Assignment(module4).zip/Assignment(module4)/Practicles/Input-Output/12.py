x=open("data.txt","r")

l1=x.readlines()

print(l1)