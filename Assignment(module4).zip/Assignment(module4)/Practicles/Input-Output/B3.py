#x=open("data.txt","a")

'''x.write("\nSunil")
x.write("\nMahi")
x.write("\nTilak")
x.write("\nWorner")
x.write("\nTandulker")
x.write("\nFaf")
x.write("\nSachin")
x.write("\nvirat")
x.write("\nrohit")
x.write("\njadeja")
x.write("\nchahal")'''

x=open("data.txt","r")

print(x.read())