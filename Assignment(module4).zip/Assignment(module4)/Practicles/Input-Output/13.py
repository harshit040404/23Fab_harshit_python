x=open("data.txt","r")

w=x.readline().split()
print(w)